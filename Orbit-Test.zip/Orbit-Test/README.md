# Orbit

A responsive Employee, Student, and Teacher Management System built with plain HTML, CSS, and JavaScript.

## Run it

Open `index.html` in any modern browser. No installation, web server, Java, PHP, or database is required.

For the best development experience, serve the folder using the VS Code Live Server extension.

## Demo accounts

| Role | Username | Password |
| --- | --- | --- |
| Admin | `admin` | `admin123` |
| Employee | `employee` | `employee123` |
| Student | `student` | `student123` |

All demo data is stored locally in the browser using `localStorage`. Use **Reset demo data** in the profile menu to restore the initial dataset.

## Important

This is a frontend-only application. LocalStorage and client-side roles are ideal for a prototype, but they are not a secure production authentication system. A real MySQL database and secure AI integration require a backend service; the UI is deliberately structured so its data helpers can later be replaced by API calls.
